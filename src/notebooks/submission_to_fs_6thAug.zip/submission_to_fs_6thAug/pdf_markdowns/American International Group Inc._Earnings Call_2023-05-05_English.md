
<start_of_page_1>
# **S&P Global**

## **Market Intelligence**

# **American International Group, Inc. NYSE:AIG FQ1 2023 Earnings Call Transcripts**

## **Friday, May 5, 2023 12:30 PM GMT**

## **S&P Global Market Intelligence Estimates**

|   | -FQ1 2023- |  | -FQ2 2023- | -FY 2023- | -FY 2024-  |
| --- | --- | --- | --- | --- | --- |
|   | CONSENSUS | ACTUAL | SURPRISE | CONSENSUS | CONSENSUS  |
|  EPS Normalized | 1.42 | 1.63 | 14.79 | 1.64 | 6.52  |
|  Revenue (mm) | 11643.77 | NA | NA | 11928.55 | 49106.00  |

**Currency: USD**

**Consensus as of May-05-2023 4:55 AM GMT**

![img-0.jpeg](img-0.jpeg)
<end_of_page_1>

<start_of_page_2>
# Table of Contents 

Call Participants ..... 3
Presentation ..... 4
Question and Answer ..... 11
<end_of_page_2>

<start_of_page_3>
# Call Participants 

## EXECUTIVES

Peter Zaffino;Chairman and CEO
Quentin John McMillan
VP, MD \& Head of Investor Relations

## Sabra Rose Purtill

Executive VP \& Interim CFO

## ANALYSTS

## Alexander Scott

Goldman Sachs Group, Inc., Research
Division

## Brian Robert Meredith

UBS Investment Bank, Research
Division

## Jon Paul Newsome

Piper Sandler \& Co., Research Division

## Meyer Shields

Keefe, Bruyette, \& Woods, Inc.,
Research Division

## Michael Augustus Ward

Citigroup Inc., Research Division
<end_of_page_3>

<start_of_page_4>
# Presentation 

## Operator

Good day, and welcome to AIG's First Quarter 2023 Financial Results Conference Call. This conference is being recorded.
Now at this time, I would like to turn the conference over to Quentin McMillan. Please go ahead.

## Quentin John McMillan <br> VP, MD \& Head of Investor Relations

Thanks very much, Michelle, and good morning. Today's remarks may include forward-looking statements, which are subject to risks and uncertainties. These statements are not guarantees of future performance or events and are based on management's current expectations. AIG's filings with the SEC provided details on important factors that could cause actual results or events to differ materially. Except as required by applicable securities laws, AIG is under no obligation to update any forward-looking statements if circumstances or management's estimates or opinions should change.

Additionally, today's remarks may refer to non-GAAP financial measures. The reconciliation of such measures to the most comparable GAAP figures is included in our earnings release, financial supplement and earnings presentation, all of which are available on our website at aig.com.

Finally, today's remarks will include results of AIG's Life and Retirement segment and Other Operations on the same basis as prior quarters, which is how we expect to continue to report until the deconsolidation of Corebridge Financial. AIG's segments and U.S. GAAP financial results as well as AIG's key financial metrics, with respect thereto, differ from those reported by Corebridge Financial. Corebridge Financial will host its earnings call on Tuesday, May 9.

With that, I'd now like to turn the call over to our Chairman and CEO, Peter Zaffino.

## Peter Zaffino;Chairman and CEO

Good morning, and thank you for joining us to review our first quarter financial results. Following my remarks, Sabra will provide more financial detail in the quarter, and then we will take questions. Kevin Hogan and David McElroy will be available for the Q\&A portion of the call.

As you saw in our press release, we reported an excellent start to the year. We continue to make meaningful progress across AIG and achieve important milestones, even in the face of ongoing complexity in the insurance industry, volatile market conditions and general economic uncertainty. We continue to diligently execute on our strategic and operational priorities, which drove very strong financial results in the first quarter and are positioning AIG for long-term value creation. Here are some highlights from the first quarter.

Adjusted after-tax income was $\$ 1.2$ billion or $\$ 1.63$ per diluted common share, representing a $9 \%$ increase year-over-year. Net investment income on a consolidated basis was $\$ 3.1$ billion. In 2022, we began to take proactive steps to improve the credit quality, construction and return characteristics of our investment portfolio as well as to reduce volatility. We saw the benefits of these actions in the first quarter and expect that to continue throughout the year. Sabra will provide additional detail on net investment income in her remarks.

Net premiums written in General Insurance grew 10\% on a constant dollar basis and adjusted for the International lag elimination that we discussed on our last call. This growth was driven by our Commercial business. Underwriting income was approximately $\$ 500$ million, a $13 \%$ increase year-over-year, which is AIG's strongest first quarter underwriting result.

The accident year combined ratio, excluding catastrophes, was $88.7 \%$, an 80 basis point improvement from prior year.
Life and Retirement reported very good results, with premiums and deposits of $\$ 10.4$ billion in the first quarter, a $44 \%$ increase year-over-year, supported by record sales in fixed annuity and fixed index annuity products.

Net flows into the General Account from Individual Retirement were approximately $\$ 1.3$ billion.
Corebridge and Blackstone have made substantial progress advancing their strategic partnership, which began in late 2021. Since that time, Blackstone has invested approximately $\$ 11$ billion on behalf of Corebridge, with an average gross yield of $6.5 \%$ and an average credit rating of A. This partnership has allowed Corebridge to expand in certain asset classes where we had limited to no access in the past, which has been very beneficial for the business and is helping to support growth, particularly in fixed annuity products.
<end_of_page_4>

<start_of_page_5>
We returned approximately $\$ 840$ million to shareholders in the first quarter through $\$ 600$ million of common stock repurchases and $\$ 240$ million of dividends. And we ended the first quarter with strong parent liquidity of $\$ 3.9$ billion. Overall, I'm very pleased with what we accomplished in the first quarter. The strong momentum we had coming into 2023 continues.

As we announced last night, the AIG Board approved the first meaningful increase to AIG's common stock quarterly dividend in many years. Starting in the second quarter, this dividend will be $\$ 0.36$ per share, an increase of $12.5 \%$. This is another significant milestone for AIG and reflects our commitment to a disciplined, balanced capital management strategy and our confidence in the future earnings power of AIG.

Corebridge is also achieving important milestones. Since its IPO in September of last year, Corebridge has paid 3 dividends to public shareholders, totaling approximately $\$ 450$ million. And yesterday, the Corebridge Board authorized a $\$ 1$ billion share repurchase program. During the first quarter, we were prepared to launch a secondary offering of Corebridge common stock, but chose not to proceed when equity markets became volatile due to issues in the financial sector.

We continue to be prepared and disciplined in terms of executing a secondary offering, which remains our base case for selling down our ownership in Corebridge, subject to market conditions and regulatory approvals. We remain committed to reducing our ownership interest in Corebridge and will explore other options that are aligned with the best interest of shareholders.

During the remainder of my remarks this morning, I'll provide more information on the following 5 topics: first, I will review the first quarter results for General Insurance; second, I will give a high-level overview of the results for Life and Retirement, and Sabra will provide more detail in her remarks; third, I will provide an update on a few strategic initiatives, including the announcement last week relating to Private Client Services, our MGA partnership with Stone Point Capital, our announcement on Tuesday of the sale of Crop Risk Services and our intent to sell Laya Healthcare, which is a part of Corebridge and Ireland's second largest health insurance provider; fourth, I will provide more information on capital management actions; lastly, I will review progress on our path to a 10\%plus ROCE, including an update on the work we are doing on the future state business model of AIG.

Turning to General Insurance. Let me provide more detail on first quarter results, starting with our strong growth in gross and net premiums written. When we refer to gross and net premiums written, all numbers have been adjusted for both foreign exchange and the impact of the lag elimination.

Gross premiums written were $\$ 12$ billion, an increase of $9 \%$, with Global Commercial growing $13 \%$ and Global Personal decreasing $4 \%$. Net premiums written were $\$ 7$ billion, an increase of $10 \%$. This growth was primarily driven by Global Commercial, which grew $11 \%$, while Global Personal grew $6 \%$.

In North America Commercial, we saw a very strong growth of $15 \%$ in net premiums written due to Validus Re, which had over $40 \%$ growth year-over-year due to the exceptional results we achieved with our January 1 treaty placements, which I discussed in detail on our last call. Lexington, which grew over 25\%, led by Wholesale Property and Casualty, double-digit growth in Captive Solutions and Glatfelter.

Focusing on Lexington for a moment, I would like to highlight a few achievements from the first quarter. The business continues to drive excellent performance, impressive growth and has consistently improved its portfolio quarter after quarter over the last couple of years. Lexington's tremendous growth has been achieved through its relevance in the marketplace and increasing its market share, not from increasing limits deployed. Strong retention, new business and rate have been the key drivers of Lexington's financial performance. Lexington has now seen double-digit rate increases for 16 consecutive quarters, and cumulative compounded rate increases totaled over $100 \%$ since the first quarter of 2018.

Additionally, over the last few years, the average size of a Lexington Property primary policy went from $\$ 100$ million in limits deployed to $\$ 5$ million. This has substantially reduced volatility in Lexington's portfolio. Our thoughtful and prudent growth strategy, together with our shift in focus to wholesale distribution, continues to serve us well, particularly in the E\&S market.

I also want to provide more color on Validus Re. We've provided significant detail on the $1 / 1$ renewal season on our last call, and I think it's worth expanding on a few items from the first quarter. Net premiums written were very strong and balanced in Validus Re, and we continue to meaningfully improve the quality of the portfolio. Rate improvements were particularly strong in U.S. Property, International Property, Marine and Energy, Casualty and Specialty Lines.

With respect to April 1 renewals across the portfolio, gross and net premiums written increased. And within International Property, limits deployed were reduced slightly, and Japan property cat risk-adjusted rates were up approximately 20\%.
<end_of_page_5>

<start_of_page_6>
As we consider our deployment strategy at the June 1 renewal cycle, which focuses on U.S. wind exposure, we will continue to maintain a prudent approach on limits deployed. We do not expect to deploy additional limits beyond our current aggregate allocated to Florida, although we do anticipate significant rate increases and improved terms and conditions. Like General Insurance, the Validus Re portfolio has been completely re-underwritten with a focus on risk-adjusted returns. The business had a terrific first quarter and is well positioned for profitable growth through the rest of the year.

Shifting back to our $15 \%$ net premiums written growth in the first quarter, this result was impressive despite the headwinds we continue to see in Financial Lines, where overall net premiums written contracted 9\% due to increased competition putting pressure on pricing as well as continued slowdown in M\&A and other transactional business.

We are one of the very few lead markets in large account public D\&O where primary rates have remained relatively flat year-overexar. In contrast, high excess public company D\&O saw rate declines greater than $20 \%$. To put this in perspective, this represents a little over 5\% of our overall North America Financial Lines business, and we will continue to manage this book very prudently. We have deep domain knowledge and experience, data, best-in-class underwriting capabilities and leading claims expertise that allow us to differentiate ourselves in the D\&O marketplace.

During the past year, we continued to see new competitors with limited experience into the high excess public D\&O market. This is driving down pricing in what is traditionally the most commoditized portion of a placement. Despite these dynamics, we remain disciplined on price and are taking a long-term view of this line of business. We have significant scale and geographic balance on our portfolio, and we will not follow the market down.

Turning to International Commercial. Net premiums written grew 6\%, primarily due to Property, which was up over 40\%; Global Specialty, which was up over 15\%; and Casualty, which was up over 15\%. Global Commercial had very strong renewal retention of $88 \%$ in its in-force portfolio, International was up 200 basis points to $88 \%$, and North America was up 100 basis points to $87 \%$. As a reminder, we calculate renewal retention prior to the impact of rate and exposure changes. And across Global Commercial, we continue to see strong new business, which was over $\$ 1$ billion in the first quarter.

International Commercial new business was over $\$ 590$ million, led by Specialty, which increased its new business by over 50\%, driven by Energy and Marine. North America Commercial, excluding Validus Re, achieved new business of over $\$ 480$ million, driven by Lexington, which saw excellent new business growth of over 50\%. With respect to rate in North America Commercial, excluding Validus Re, rates increased $7 \%$ in the first quarter or $8 \%$ if you exclude workers' compensation, and the exposure increase was $2 \%$.

In North America Commercial, rate was driven by Lexington wholesale, which was up 26\% with Wholesale Property up 35\%. For Lexington Property Wholesale, this was its strongest quarterly rate increase. Rate in Retail Property was also up significantly at 32\%; International Commercial rate increases were 8\%, driven by Talbot at 16\%, International Property at 11\% and Specialty at 9\%. The exposure increase in the International portfolio was $2 \%$. Rate plus exposure remains above loss cost trend at $9 \%$ in North America, $10 \%$ if you exclude workers' compensation and $10 \%$ in International.

Turning to Personal Insurance. First quarter results reflect our continued repositioning of this business, especially PCG, given our announcement of the creation of a managing general agency in partnership with Stone Point Capital. I will provide more information on the MGA later in my remarks.

North America Personal net premiums written increased 57\%, driven by lower quota share cessions in PCG at January 1, as we transition to writing the business as an MGA, along with the recognition of an improved portfolio. The combination of improved pricing in our admitted business and more business migrating to the non-admitting market has a very positive impact on PCG's accident and policy or loss ratios. This will earn in through the second half of 2023 and into 2024.

Entering 2023, we required less excess of loss reinsurance on the upper end of our reinsurance program due to realized reduction in PCG's PMLs at all return periods as a result of ongoing improvements in risk selection and reductions in aggregate in peak zones. More specifically, all peril and all return periods from 1 in 20 to 1 in 1,000 reduced on average by $40 \%$, while those same return periods with respect to wildfire reduced on average by $60 \%$. These dynamics further impacted net premiums written in the first quarter.

Syndicate 2019 continues to act as a mechanism to enable third-party capital providers to support PCG's high and ultra-high net worth business for the 2023 accident year.

In terms of expectations for PCG for the full year, we expect net premiums written growth to be at or higher than we saw in the first quarter, the loss ratio to meaningfully improve and the acquisition ratio and general operating expense to also improve.
<end_of_page_6>

<start_of_page_7>
Turning to International Personal. Net premiums written were largely flat in the first quarter, Travel and Warranty grew while Personal Property declined, all driven by a further refinement of our cat reinsurance cost allocation methodology, making year-overexar comparisons difficult. Accident \& Health had some timing issues that impacted net premiums written in the first quarter. We expect to see growth in International Personal for the remainder of 2023 and believe results will continue to strengthen as we move through the year.

Shifting to combined ratios. As I noted earlier, the first quarter accident year combined ratio, excluding catastrophes, was $88.7 \%$, an 80 basis point improvement year-over-year. In Global Commercial, the first quarter accident year combined ratio, excluding catastrophes, was $84.9 \%$, a 110 basis point improvement year-over-year and we reported a $24 \%$ increase in underwriting income.

The North America Commercial accident year combined ratio, excluding catastrophes, was $85.7 \%$, a 240 basis point improvement year-over-year. The International Commercial accident year combined ratio, excluding catastrophes, was essentially flat at $83.7 \%$, which is an outstanding result. Global Personal reported a first quarter accident year combined ratio, excluding catastrophes, of $98.6 \%$, a 120 basis point increase from the prior year quarter, largely due to a decrease in earned premium from our deliberate reduction in gross exposure in PCG in North America.

Now let me comment on catastrophes. The cat loss ratio in the quarter was $4.2 \%$ or $\$ 264$ million of catastrophe losses. Our largest loss in the period was from 2 storms in New Zealand, which accounted for $\$ 126$ million of catastrophe losses.

Looking at North America, total losses from catastrophe-related activities in the first quarter were $\$ 116$ million, which includes Validus Re. In International, excluding Japan, we have eroded approximately $\$ 75$ million of our aggregate retention and have approximately $\$ 75$ million net remaining, plus the annual aggregate deductible for each cat loss for the rest of the year. As we described in our last call, the reinsurance program we structured at this year's January 1 renewal provides us with the ability to manage volatility and severity. Looking ahead to the rest of 2023, we expect to see very strong top line growth in General Insurance.

Turning to Life and Retirement. The business delivered strong performance in the first quarter. Adjusted pretax income was $\$ 886$ million for the first quarter, and adjusted return on segment equity was $10.7 \%$. First quarter results benefited from continued growth in spread-based products and related spread income. As I mentioned earlier, premiums and deposits grew significantly in the first quarter, driven by strong new individual retirement business, which, despite increasing surrenders related to interest rates, contributed to growth in the General Account. The balance sheet and capital position of Corebridge remains strong with $\$ 1.8$ billion of parent liquidity.

Turning to our strategic initiatives. Last week, we executed a definitive documentation with Stone Point Capital for the launch of Private Client Services, an MGA that will serve the high and ultra-high net worth market. We are excited about the prospects for PCS and are confident of the value this new operating structure will deliver for clients, brokers and other stakeholders. We look forward to continuing this journey with the PCS management team and the ongoing support of Stone Point Capital.

Subject to regulatory approvals, the MGA is expected to formally launch in the third quarter of this year, and we expect to bring on additional capital providers through the second half of 2023. As part of our ongoing review process, we regularly assess the composition of our portfolio of businesses to ensure it is aligned with our long-term strategy and best positioned to create value for our shareholders and other stakeholders.

As part of this review, as you saw in our announcement on Tuesday, we executed a definitive documentation to sell Crop Risk Services, or CRS, to American Financial Group for $\$ 240$ million. We acquired CRS as part of our broader acquisition of Validus Holdings in 2018. AIG will continue to write business for the 2023 spring crop season, which ends June 30. We expect approximately $\$ 700$ million to $\$ 800$ million of net premiums written for $2023,75 \%$ of which booked in the first quarter. Starting in the third quarter, AIG will act as a fronting partner for American Financial Group during a transitional period.

For full year 2023, we expect to retain about $\$ 800$ million to $\$ 900$ million of earned premiums, $\$ 750$ million of which we'll earn in over the remainder of the year. CRS is a well-run and attractive business, led by a high-quality management team. In American Financial Group, we have found a high-quality partner for CRS and its employees and believe the business will benefit from being part of a larger combined platform. We also continually review the product portfolio and geographic footprint of Corebridge as we position this business for the future as a fully stand-alone company.

After a comprehensive review of the health product offering, we decided to evaluate strategic alternatives and a potential sale of Laya Healthcare, the private medical insurance business in Ireland. We believe this will help to streamline the Corebridge portfolio and allow it to focus on Life and Retirement products and solutions.
<end_of_page_7>

<start_of_page_8>
Turning to capital management. The first quarter marked another quarter of continued progress and execution of our balanced strategy. In addition to the first quarter share repurchases and dividends that I mentioned earlier, against the backdrop of an unstable macroeconomic environment, we thought it was prudent to raise $\$ 750$ million of debt at the end of March. This provided us with financial flexibility to pay down a near-term debt maturity and complete additional share repurchases at what we viewed as attractive share prices.

Turning to return on common equity. We remain highly committed and laser-focused on delivering a 10\%-plus ROCE. Through the first quarter, we continued to make meaningful progress on the 4 components of our path to deliver on this commitment. As a reminder, these components include sustained and improved underwriting profitability; executing on a simpler, leaner business model across AIG; operational separation and deconsolidation of Corebridge; and continued balanced capital management. Given the number of strategic initiatives we are executing at once, we are taking a long-term view while measuring progress in 90-day increments. We advanced each component during the first quarter and expect this to continue throughout 2023.

As I discussed earlier, our first quarter financial results were excellent, with continued top line growth and improvement in underwriting profitability in General Insurance. Over the last few months, we accelerated our work to establish AIG's future state business model. Sequencing has been very important on our journey and the work that's been accomplished over the last few years on the General Insurance turnaround, AIG 200, the separation and IPO of Corebridge and restructuring of our investment management group. This has positioned us to move forward as a more focused and simplified AIG.

Evolving our future state business model will result in us moving away from the conglomerate structure AIG operated in for decades. We will eliminate overlap and significantly reduce decentralized infrastructure across the company, which will lead to a leaner business model, particularly in our operations. In future state, we expect a redefined AIG parent expense structure to be approximately $1 \%$ to $1.5 \%$ of premiums, which today is roughly $\$ 250$ million to $\$ 350$ million.

AIG parent will have 5 primary roles and objectives: public company matters, including finance, legal, compliance and regulatory oversight as well as corporate governance; communications with key stakeholders, including the investment community, rating agencies, regulators, policymakers and AIG colleagues; risk management, culture, performance and human capital management; and strategy, including business development, M\&A and design and execution of key initiatives. As we progress our future state business model, we anticipate achieving approximately $\$ 500$ million in cost reductions at AIG parent and a cost to achieve of around $\$ 400$ million with substantially quicker earn-in of savings that we achieved with AIG 200.

As expense savings begin to earn through, the reductions will largely be seen in other operations, which is where general operating expenses are currently accounted for.

With respect to Corebridge, I took you through our current thinking on separation and timing of the secondary offerings.
Lastly, on capital management. We continue to maintain appropriate levels of capital in our subsidiaries to support profitable growth. We remain on track to reduce AIG common stock outstanding to be between 600 million and 650 million shares and achieve a debt-to-capital leverage at the lower end of our $20 \%$ to $25 \%$ range post deconsolidation of Corebridge.

As I noted earlier, we increased our common stock dividend by $12.5 \%$, starting in the second quarter of this year. And in addition to our stock repurchases in the first quarter, to date, we have repurchased $\$ 240$ million of AIG common stock in the second quarter. Apart from the progress we're making on these components of our path to a 10\%-plus ROCE, we also expect tailwinds from higher reinvestment yields. We are confident that our continued progress on strategic initiatives and our capital management strategy will allow us to achieve our ROCE targets and deliver long-term profitable growth that benefits all of our stakeholders.

I will now turn the call over to Sabra.

# Sabra Rose Purtill 

Executive VP \& Interim CFO
Thank you, Peter. This morning, I will cover 2 accounting changes, provide more details on first quarter results and give an overview of Commercial Mortgage Loans. First, the 1-month lag in financial reporting for the General Insurance International segment was eliminated last quarter. The lag elimination did not impact earnings significantly, but it did affect premiums written comparisons to 2022. Details on the premium impacts are in the financial supplement on Page 26.

Second, we adopted the change in accounting standard for certain long-duration products, commonly called LDTI. Yesterday, 8Ks were filed that provide restated prior year financial results for AIG and Corebridge. The cumulative effect at year-end 2022 was an increase of $\$ 1.5$ billion to adjusted equity and an increase of $\$ 1.0$ billion to total shareholders' equity. This impact is consistent
<end_of_page_8>

<start_of_page_9>
with our previous guidance. As a reminder, this is a GAAP accounting change only and does not impact statutory results, insurance company cash flows or economic returns. Going forward, we expect a modest run rate increase in L\&R APTI and less market and mortality-driven volatility from the change in accounting standards.

Turning to the quarter, as Peter mentioned, AIG's first quarter adjusted after-tax income was $\$ 1.2$ billion or $\$ 1.63$ per diluted share, up $9 \%$ from last year on a restated basis and up $25 \%$ from originally reported. Key trends in the quarter and similar to the last 3 quarters were higher GI underwriting results and higher income from fixed maturities and loans and lower alternative investment income. Compared to the prior year quarter, there was a higher impact from noncontrolling interest from the Corebridge IPO in 3Q'22.

Consolidated net investment income on an APTI basis was $\$ 3.1$ billion. Similar to the fourth quarter, income from fixed maturities and loans in both GI and L\&R rose sequentially and over the prior year, while returns on alternative investments were down \$593 million compared to very strong annualized returns of $28 \%$ last year.

Income on fixed maturities and loans rose by $\$ 573$ million over the prior year, with average new money reinvestment rates of $5.35 \%$, about 220 basis points above sales and maturities. The yield rose to $4.29 \%$, up 78 basis points from 1Q'22 and 23 basis points over 4Q'22. Part of the increase in fixed maturity yields resulted from our proactive repositioning over the last 2 quarters in the U.S. GI portfolio. We sold and reinvested about $\$ 6$ billion in fixed maturities, resulting in a realized loss of $\$ 224$ million, but added 9 basis points of GI yield improvement for the quarter. We expect incremental yield pickup from this repositioning in 2Q'23 and also from higher reinvestment rates throughout 2023 based on the current rate and spread environment.

Turning to the segments. GI adjusted pretax income, or APTI, was $\$ 1.2$ billion, $\$ 37$ million higher than 1Q'22, principally due to a $\$ 56$ million increase in underwriting income from both higher-earned premiums and a 1 point improvement in the calendar year combined ratio, which was $91.9 \%$. Peter covered underwriting results in detail, but I want to add that GI reserves had favorable prior year development, net of reinsurance at prior year premiums of $\$ 54$ million.

Turning to L\&R results for the first quarter. APTI was $\$ 886$ million, down $\$ 48$ million compared to $\$ 934$ million in 1Q'22 as restated. Consistent with GI, L\&R had a strong increase in base portfolio investment income, but lower alternative investment income. Mortality experience improved, but fee income was down due to lower capital market levels compared to a year ago. As Peter noted, L\&R premiums and deposits were very strong at $\$ 10.4$ billion. Notably, Individual Retirement sales were $\$ 4.9$ billion, a $26 \%$ increase over the prior year quarter with record levels of fixed and fixed index annuity sales because of higher crediting rates.

Group Retirement deposits grew 19\%, with higher out-of-plan fixed annuity sales and new plan acquisitions. Strong fixed and fixed index annuity sales, net of surrenders, resulted in $\$ 1.3$ billion of positive flows to the General Account in Individual Retirement, up from $\$ 0.7$ billion last year. While surrenders are up, they remain below projections. Variable annuity net flows, which impact the separate account, were negative.

To conclude on earnings for the quarter, other operations adjusted pretax loss, or APTL, was $\$ 491$ million, a $\$ 70$ million increase due to lower APTI from consolidated investment entities in Asset Management, which had strong private equity results in 1Q'22. Corporate GOE decreased $\$ 27$ million from the prior year and $\$ 77$ million from 4Q'22 despite $\$ 29$ million of additional expense related to the corporate separation.

Turning to AIG's balance sheet. Book value per common share was $\$ 58.87$ at quarter end, up $7 \%$ from year-end, principally due to higher valuations on available-for-sale securities due to lower long-term interest rates. Adjusted book value was $\$ 75.87$ per share, roughly flat with year-end. At the end of March, we issued $\$ 750$ million of senior notes, a portion of which was used to pay down an April bond maturity.

Our leverage ratio declined to $32.8 \%$, down about 1 point from year-end even with the new issuance due to the change in AOCI in the quarter. Excluding AOCI and the Fortitude-embedded derivative, debt leverage was $26.3 \%$.

For the first quarter of 2023, AIG's consolidated adjusted ROCE was $8.7 \%$, comprised of $11.6 \%$ in GI and $10.7 \%$ in L\&R. As Peter discussed, we are laser-focused on achieving a 10\%-plus ROCE post deconsolidation.

Peter provided a lot of detail on the quarter. So I'll use my remaining time to cover investments, particularly Commercial Mortgage Loans, given the recent focus on this asset class. First, I want to emphasize that our investment portfolio is grounded in the liability profile of our 2 insurance businesses. We strive to achieve strong risk-adjusted returns while matching the duration, cash flow and liquidity needs of the liabilities.

Over the last several years, we have improved the risk profile of the investment portfolio by reducing capital-intensive, less liquid or more volatile assets such as hedge funds. With the onset of COVID and, again, with rising interest rates last year, we further
<end_of_page_9>

<start_of_page_10>
tightened investment guidelines and moved up in quality, including the GI repositioning mentioned earlier and also sales of L\&R non-investment-grade assets.

Turning to our Commercial Mortgage Loan exposures. I'll start by noting that our mortgages are senior secured loans on high-quality properties that are well diversified by type and geography with strong loan to values, or LTVs, averaging $59 \%$ and debt service coverage ratios averaging 1.9 x . We are the lead lender on more than $80 \%$ of our loans, which gives us important control rights.

Excluding Fortitude funds withheld assets, we had $\$ 33.8$ billion of Commercial Mortgage Loans at the end of March, of which $\$ 30.3$ billion were at Corebridge and $\$ 3.5$ billion at General Insurance. The largest property type is multifamily housing or apartments, about $40 \%$ of our Commercial Mortgage Loans. Industrial Property loans are about $16 \%$ of the portfolio. Both multifamily and industrial are performing well. We are, however, focused on traditional U.S. office, which is $\$ 5.4$ billion or $2 \%$ of AIG's invested assets. Our U.S. office allocation has been shrinking for several years, particularly when we tightened underwriting standards further for office, retail and hotels with the onset of COVID. Currently, $94 \%$ of the office loans are high-quality rated CM1 or CM2 with debt service coverage averaging about 2.1 x and weighted average LTVs of $64 \%$. Valuations are updated annually by a third party, and we continue to monitor valuations given rising cap rates.

We also have a credit or CECL allowance against the portfolio of about $\$ 330$ million or $3.7 \%$ against the office loan portfolio and $\$ 584$ million for the total commercial mortgage portfolio or $1.7 \%$, which is higher than many peers as we use CMBS default data in our methodology.

Roughly $3 / 4$ of the building securing the loans are Class A or newer buildings with better amenities. The majority are in the top 5 U.S. metropolitan areas and concentrated in central business districts, including in New York City, which historically has been one of the strongest office markets in the country.

Today, we are intensely focused on office loan maturities in the next 2 years, about $\$ 2$ billion or 28 loans. We are already in discussions with many borrowers about their plans and our requirements for refinancing or extension, including additional equity revised terms or other commitments. While valuations are under pressure, cash flows are the primary source of debt service for our loans, and we will continue to monitor the loans carefully. We look forward to updating you on our investment performance in the quarters ahead.

To wrap up, our first quarter 2023 results demonstrate continued sustained and strong financial results, rising investment portfolio yields, significant progress against strategic initiatives, robust capital and liquidity and continued progress on our path to a 10\%-plus ROCE.
With that, I will turn the call back over to Peter.
<end_of_page_10>

<start_of_page_11>
# Question and Answer 

## Operator

[Operator Instructions] Our first question comes from Meyer Shields with KBW.

## Meyer Shields <br> Keefe, Bruyette, \& Woods, Inc., Research Division

Peter, I wanted to address one aspect of growth. And you covered, I think, a ton of detail, which is helpful. But the net-to-gross ratio didn't change. And I would have thought that based on the current dynamics in the property cat market and much improved performance on a lot of casualty lines that have been heavily reinsured, that we would see AIG retaining more of its gross premium. I was hoping you could talk through that.

## Quentin John McMillan <br> VP, MD \& Head of Investor Relations

Meyer, this is Quentin. I think we're having a little audio technical difficulties. So if you can bear with us for just one moment, we'll be back in just 1 second.
[Technical Difficulty]

## Peter Zaffino;Chairman and CEO

Can you hear me now?

## Quentin John McMillan <br> VP, MD \& Head of Investor Relations

Yes. You're coming through loud and clear, Peter. Meyer, do you want to just repeat your question?

## Peter Zaffino;Chairman and CEO

I heard the questions, Quentin. Sorry, I actually had a good answer too. I just was on -- not a microphone that worked. So Meyer, back to your question is that we had -- you have to look at the portfolio composition to be able to answer the question. And Validus Re obviously had meaningful growth on gross and net during the quarter. And so, therefore, it's hard to look at the cessions year-overyear when you're having a retro program that fits the portfolio that you're underwriting.

We've never had a strategy that we're going to time the market with our reinsurance partners. They've always been strategic. They've always been supportive. They've always deployed the capital in support of AIG. And so we were not going to do anything, other than to try to get the appropriate terms and conditions with them and have not really changed much of our risk appetite in terms of taking that. And I think that has generated a terrific result for us on net premium written, but also on the combined ratios.

So I think I wouldn't look into just one quarter in terms of discussions. And as I said, we have a lot in terms of the guidance I've given on PCG, which we will still assume a lot of risk. And I guess -- let's just play it out for the full year. We're not looking to do anything materially different.

## Meyer Shields <br> Keefe, Bruyette, \& Woods, Inc., Research Division

Okay. Perfect. That's helpful. And I don't know if this is even a good question. But does the changing approach to North American Personal Lines have any implications for the International Personal segment?

## Peter Zaffino;Chairman and CEO

It really doesn't, Meyer. I mean they're really distinct businesses. I mean, certainly, our Travel and Warranty have platforms that are global and that give us capabilities across the world. But as you know, Private Client Group, in particular in the U.S., is a unique asset. Again, the guidance I gave in the prepared remarks, it's one that we believe we will grow the net premium written because we don't believe we need the quota shares anymore after the excellent job the team has done in repositioning and re-underwriting that portfolio. We have substantially less cat in aggregates that we once did. So I think that's something that will be a little different in terms of -- if you look at International.
<end_of_page_11>

<start_of_page_12>
While International, we have a terrific Personal Insurance business. Some of it was affected by COVID. It's growing back, between Japan's Personal Insurance, our Global Accident \& Health, which is predominantly International as well as our Travel and Warranty, which are rebounding in terms of growth. So I don't think that there's a lot of correlation between International and North America. But both we believe in and we're investing in, and you'll continue to see improvement. It will just be at a different pace because of the anomaly of the high net worth business.

# Operator 

Our next question comes from Paul Newsome with Piper Sandler.

## Jon Paul Newsome Piper Sandler \& Co., Research Division

I also had a couple of questions on the Personal Lines business, sort of micro and macro. My understanding, and tell me if I'm wrong, is that much of the change to the MGA is scale related. And does that mean that we should expect the expense ratio to fall over time as the MGA gain speed? And maybe just correct me if I'm wrong, does that shift around how we think about sort of the relationship between expenses and losses in that business over time, not necessarily next quarter, but over time?

## Peter Zaffino;Chairman and CEO

Paul, let me make sure I understand the question. I mean are you asking in terms of what's going to happen to the expense ratios over time as we start to reposition and grow the business?

## Jon Paul Newsome

Piper Sandler \& Co., Research Division
Yes, I am.

## Peter Zaffino;Chairman and CEO

Okay, thank you. This year, as I said in my prepared remarks, we are going to see a lot more net premium written. The reason for that is as we were repositioning the business over the last 2 years, we bought very low excess of loss catastrophe reinsurance. We bought a substantial quota share. We ceded a significant amount of Syndicate 2019, which also had retrocession behind that in a variety of forms. And so the net premium written was not that large as you've seen. And so part of the repositioning with Stone Point and having an MGA, one is that we think there's tremendous growth opportunities that exist in the business with other capital providers and believe that how we have repositioned the business through rate increases and disciplined underwriting on the admitted side, and then also the non-admitted became an option for us to have flexibility in form and rate. And so that was very positive for us in terms of repositioning the business.

As we look to 2023 and beyond, we believe that the business is going to perform much better, much more profitable. And we don't need to cede off as much on the quota share. So as a result, in this particular calendar year, what you'll see is a lot of net premium written growth, improved loss ratios and both the expense ratio on an acquisition basis as well as the general operating expenses will improve. And so the overall combined ratio will improve dramatically. We're not going to be where we want to be in 2023, but believe by the time we hit 2024, those results will continue to improve.

## Jon Paul Newsome

Piper Sandler \& Co., Research Division
That's great. And maybe a big picture talking about a little bit more of the big picture cat exposures. I mean it looks like -- I'm just looking at the General Insurance overall, the cat load has pretty much stabilized, but that's been a huge part of the improvement over time. Do you think we're pretty much done? And again, I'm not talking about next quarter. I'm talking about years to come, from making this portfolio of businesses have the cat load that you want. I mean is this sort of the run rate we should be thinking about in the long term?

## Peter Zaffino;Chairman and CEO

The team has done an incredible job of underwriting the Property line of business across all of AIG over multiple years. Our ability to reposition that portfolio, we talk a lot about aggregates, we talk a lot about reductions and we talked a lot about where we want to grow. I think we were in a terrific place as we enter 2023 from that hard work. And when I look at where we decided to grow, we constantly talk about where the best risk-adjusted returns available in the marketplace, where is our capacity most valued and where we value for clients.
<end_of_page_12>

<start_of_page_13>
So when I look at where we've grown, Validus Re certainly was a big part of that. Lexington has been hitting it out of the park on just about every aspect, whether it's top line growth, retention, new business, rate, like how they actually are more relevant in the marketplace. Working with Dave McElroy and the team, we've taken back some of the Retail Property. But then in other parts of the world, we've taken it back up. So like we've repositioned the portfolio and then have coupled that with the reinsurance to reflect the portfolio it is today.

So if I summarize what happened at $1 / 1$ is that we saw terrific opportunities for Validus Re to grow. So we took the PMLs up there a little bit. We dramatically took the PMLs down in the Private Client Group substantially. Again, I gave the return period, that every return period from 1 in 20 to 1 in 1,000 was substantially reduced on all peril and, in particular, on wildfire. And we actually took the commercial book. Despite our growth in Lexington and Global Specialty, we took those PMLs down as well. So overall, when you look at the increased PMLs in the first quarter of Validus Re and the reductions that we had in the Commercial business and the Personal business, our overall PMLs are down year-over-year.

I think that's a tremendous outcome when you look at where we're growing, how we're driving risk-adjusted returns, how we couple that with reinsurance and our overall net PMLs are down at all the critical return periods. So I think all of that's been purposeful. The team has done an unbelievable job executing.

# Operator 

Our next question comes from Michael Ward with Citi.

## Michael Augustus Ward <br> Citigroup Inc., Research Division

I was hoping you could discuss how you think about your excess capital just given the macro volatility. You raised some debt, it sounds like, for some prudent liquidity and for buybacks. I guess given the share price, I guess, the buyback could have been a little bit higher. So just wondering from here, should we expect that you'll sort of hold a bit more capital against uncertainty?

## Peter Zaffino;Chairman and CEO

Thank you. We were very disciplined in terms of the $\$ 750$ million debt raise. Again, I'm going to let Sabra comment a little bit more on liquidity and capital. But when I look at all the different components of our capital strategy, I think we executed incredibly well in the first quarter. I mean our primary focus is to make sure that we have the appropriate capital levels in the insurance company subsidiaries for growth, and so it gave us tremendous opportunities at $1 / 1$ as it will give us for the entire year.

Very focused on our leverage ratios and being at the lower end just to give us financial flexibility. And of course, I've been leading everybody every quarter saying, we're looking at the dividend and to have a $12.5 \%$ dividend increase not only helps complete some of the capital management strategy we've been talking about, but also shows the confidence that we have on our earnings and how we're managing liquidity. But I'll have Sabra comment a little bit on the parent liquidity and our approach to capital. And it is proven to be conservative at this time. Sabra?

## Sabra Rose Purtill <br> Executive VP \& Interim CFO

Thank you, Peter. Yes. And I would just comment that, first of all, we look at our capitalization, both in base and stress scenarios. I mean this is just what I would call basic risk management procedures that we do. And we're very comfortable with our balance sheet even in the current environment where, obviously, there's a lot of stress on the system with the debt ceiling and the rest.

From where we sit today, we have very strong robust capital and liquidity. And as Peter noted, the Board was comfortable raising the dividend for the first time in many, many years because of the significant turnaround of GI underwriting results over the past 5 years. So as we sit here today, yes, we'll continue to evaluate our financial flexibility for additional share repurchases, keeping in mind that our first goal is to maintain a strong balance sheet that can withstand turbulent times.

## Michael Augustus Ward <br> Citigroup Inc., Research Division

Very helpful. I guess maybe on the Crop deal, I guess, I was just wondering are there -- if you could maybe point to any other sort of targeted units where you could do sort of similar value unlocking deals there as you sort of work towards margin improvement and simplification.

## Peter Zaffino;Chairman and CEO
<end_of_page_13>

<start_of_page_14>
Great. Thank you. We're always looking at the portfolio and looking at areas where we can add, where we can improve the overall structure of AIG and looking at the different parts of the world that we compete in. I think Crop is a little bit anomalous just because we really do believe it's a very good business, but you know how it works, which is driven by commodity prices and yields. And I think that having scale is really important. While the top line that we publish on a gross and net basis is significant, that's gone up $40 \%, 50 \%$, if not more, over the past several years based on those components.

And we believe that Crop Risk Services, in order for it to achieve its ultimate potential that being part of a bigger enterprise and one that valued it like Great American, was the prudent approach for us at this time. And so that was something that was specific to that business. It was specific to how we look to strategically position AIG for the future and also making certain that with Crop Risk Services, it had a great opportunity to scale and realize this potential. So I feel like we really found a very good partner and that's really what drove the outcome for CRS.

# Operator 

Our next question comes from Alex Scott with Goldman Sachs.

## Alexander Scott

## Goldman Sachs Group, Inc., Research Division

First one I had for you is on the separation at Corebridge. I know you mentioned the base case is still secondaries, but I think you also mentioned that you were considering some alternatives. So I just wanted to see if you could extrapolate on that a bit at all. What kind of alternatives could you look towards? And how could some of those things potentially improve things for shareholders?

## Peter Zaffino;Chairman and CEO

Yes. Thanks, Alex. I'll try to expand a bit on it. Because as you can imagine, there's not a lot of more detail that I can really share beyond my prepared remarks. We do believe the secondary is the preferred path. But obviously, it's subject to market conditions as we saw in the first quarter, but we're prepared to go in the second quarter.

Our objective has not changed, which is for AIG to reduce its ownership stake in Corebridge over time. And so I think it's prudent, looking at a variety of different options to make sure that we're driving value for shareholders and provide a path that will recognize the value of Corebridge. Corebridge has done a terrific job since we've announced that we were going to commence upon doing an IPO, getting themselves positioned to be an independent public company and the stock was trading at a deep discount in the first quarter.

I mean one of the alternatives, I don't think we're going to go much beyond this, was what we announced on Laya Healthcare. And so making sure we're sticking to the core business of Corebridge. And we'll just give you updates as the weeks and over the next month progresses. But we're prepared and are very excited about hopefully getting the secondary done in the second quarter.

## Alexander Scott

## Goldman Sachs Group, Inc., Research Division

Got it. Follow-up I had is on corporate expenses. I think it was the first time you guys gave a bit more explicit guidance around where corporate expenses for RemainCo could shake out at that $1 \%$ to $1.5 \%$ premiums. And I just wanted to make sure I understood some of the mechanics. I mean when I think about that level, I mean, is that what I should expect in sort of Corporate GOE, overall Corporate costs? I mean how do I think about that? And then just a technical kind of question. The investment that I think you mentioned leading up to that, will that go through operating and also be reflected in Corporate?

## Peter Zaffino;Chairman and CEO

Yes. So we try to provide as much detail as we could on the expense savings. Certainly, let me start with AIG 200 because we still have more to earn through on AIG 200 savings in 2023 and 2024. So over $50 \%$ of that will be earned in mostly through the second and through fourth quarter of 2023. We have begun to separate Corebridge. And -- but upon deconsolidation, approximately $\$ 300$ million of the AIG Corporate expenses will move to Life and Retirement. So that's another variable that you need to consider.

We also gave guidance as we're working through our future state business model, $\$ 250$ million to $\$ 350$ million of parent expenses. And then the remaining will be worked through to fit the business model in terms of what we're designing for the future of AIG. We want to make sure that we have a lean model that's not synonymous with expense cutting, but it is how we're going to be in each market, how we face off with our clients and our distribution partners to maximize growth and all the opportunities that present them themselves to AIG and making sure that we have a structure that supports that.
<end_of_page_14>

<start_of_page_15>
Sequencing is important. We've been working on a variety of different initiatives that are substantial, and we're performing out all of them, making certain that General Insurance has the capital and support it needs to grow in this market; repositioning some of our businesses, which we covered in my prepared remarks; making sure we complete AIG 200, the operational separation; preparing to do the secondary; advancing Corebridge capital structure; and then making sure that we're working to get this future state business model implemented, but it has to be in that order. And we've given you the guidance. We've done the work. We know that's the savings that we'll achieve.

Some of that's going to go into the business. And so the business has to get rationalized and leaner in order to be able to absorb more expenses. But our commitment is the $\$ 500$ million in addition to the guidance that we've given in the other components. And we're highly confident we'll execute on that at the right time, meaning we've got to get these other things further along. And then when we have clear line of sight in terms of separation, we'll be able to execute on the target operating model.

# Operator 

Our next question comes from Brian Meredith with UBS.

## Brian Robert Meredith <br> UBS Investment Bank, Research Division

Peter, you gave us a lot of detail on the growth in the Commercial Lines. There's, obviously, very strong growth. I'm trying to just dumb it down a little bit here. If we look at what the growth is X, let's call it, Validus Re crop, what would have looked like? And what was the tailwind from Validus Re crop just from the Commercial Lines growth on a year-over-year basis? And the reason I'm asking is, those are obviously very big first quarter premium numbers. So I just want to make sure I'm not extrapolating that for the remainder of the year.

## Peter Zaffino;Chairman and CEO

Thanks, Brian. Certainly, Validus contributed a meaningful amount to the growth. But look, we bought a lot of retro. It's the first quarter. It's not all property. So each quarter is a bit different in terms of not being able to straight line it.

Crop Risk Services had low single-digit growth. So that was not a contributor at all in terms of net premium written. We had very strong, as I said, growth in our Specialty business, in Lexington, in our Property, offset a little bit by Financial Lines. But I put the guidance in there because I feel very confident that we're going to have strong growth throughout the year. Even though the quarters are a little bit different, businesses like Europe is heavy 1/1. And we start to have sort of different mix of business over the second, third and fourth. But I feel seeing the pipeline, looking at how you grow, I mean, the first thing I would look at is what's the client retention and how is the new business, what's happening with rate and are we growing in the businesses that we want to. And I think we are checking all the boxes here and see that those businesses have more opportunity in the future, not less. And so I think the growth that you saw in the first quarter, obviously, there's a mix of business, but I would expect to see similar growth throughout the rest of the year.

## Brian Robert Meredith

UBS Investment Bank, Research Division
Okay. Very helpful. And then second question, just curious, some other companies are talking about how the Commercial Property markets are even further firming up in the second quarter. There's more business available. Are you seeing the same kind of dynamics or things actually continuing to improve here in the Commercial Property markets?

## Peter Zaffino;Chairman and CEO

Yes. Thanks, Brian. Yes, we are seeing that. I mean, again, it's early in the second quarter, but views on April. And as we look to the rest of the second quarter, we're seeing Property continue to firm up and getting stronger than it was in the first quarter. So that's something that we're trying to be focused on clients, making sure we're driving value and we have a lot of capital to deploy. So we expect to be trading actively in the second quarter.

Okay. Well, thank you, everybody. Sorry for the 1-minute hiccup on the microphone, but greatly appreciate you dialing in, and I wish everybody a great day. Thank you.

## Operator

Thank you. This does conclude the program. You may now disconnect. Everyone, have a great day.
<end_of_page_15>

<start_of_page_16>
Copyright © 2023 by S\&P Global Market Intelligence, a division of S\&P Global Inc. All rights reserved.
These materials have been prepared solely for information purposes based upon information generally available to the public and from sources believed to be reliable. No content (including index data, ratings, credit-related analyses and data, research, model, software or other application or output therefrom) or any part thereof (Content) may be modified, reverse engineered, reproduced or distributed in any form by any means, or stored in a database or retrieval system, without the prior written permission of S\&P Global Market Intelligence or its affiliates (collectively, S\&P Global). The Content shall not be used for any unlawful or unauthorized purposes. S\&P Global and any third-party providers, (collectively S\&P Global Parties) do not guarantee the accuracy, completeness, timeliness or availability of the Content. S\&P Global Parties are not responsible for any errors or omissions, regardless of the cause, for the results obtained from the use of the Content. THE CONTENT IS PROVIDED ON "AS IS" BASIS. S\&P GLOBAL PARTIES DISCLAIM ANY AND ALL EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, ANY WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE OR USE, FREEDOM FROM BUGS, SOFTWARE ERRORS OR DEFECTS, THAT THE CONTENT'S FUNCTIONING WILL BE UNINTERRUPTED OR THAT THE CONTENT WILL OPERATE WITH ANY SOFTWARE OR HARDWARE CONFIGURATION. In no event shall S\&P Global Parties be liable to any party for any direct, indirect, incidental, exemplary, compensatory, punitive, special or consequential damages, costs, expenses, legal fees, or losses (including, without limitation, lost income or lost profits and opportunity costs or losses caused by negligence) in connection with any use of the Content even if advised of the possibility of such damages. S\&P Global Market Intelligence's opinions, quotes and credit-related and other analyses are statements of opinion as of the date they are expressed and not statements of fact or recommendations to purchase, hold, or sell any securities or to make any investment decisions, and do not address the suitability of any security. S\&P Global Market Intelligence may provide index data. Direct investment in an index is not possible. Exposure to an asset class represented by an index is available through investable instruments based on that index. S\&P Global Market Intelligence assumes no obligation to update the Content following publication in any form or format. The Content should not be relied on and is not a substitute for the skill, judgment and experience of the user, its management, employees, advisors and/or clients when making investment and other business decisions. S\&P Global Market Intelligence does not act as a fiduciary or an investment advisor except where registered as such. S\&P Global keeps certain activities of its divisions separate from each other in order to preserve the independence and objectivity of their respective activities. As a result, certain divisions of S\&P Global may have information that is not available to other S\&P Global divisions. S\&P Global has established policies and procedures to maintain the confidentiality of certain nonpublic information received in connection with each analytical process.

S\&P Global may receive compensation for its ratings and certain analyses, normally from issuers or underwriters of securities or from obligors. S\&P Global reserves the right to disseminate its opinions and analyses. S\&P Global's public ratings and analyses are made available on its Web sites, www.standardandpoors.com (free of charge), and www.ratingsdirect.com and www.globalcreditportal.com (subscription), and may be distributed through other means, including via S\&P Global publications and third-party redistributors. Additional information about our ratings fees is available at www.standardandpoors.com/usratingsfees. (c) 2023 S\&P Global Market Intelligence.
<end_of_page_16>
